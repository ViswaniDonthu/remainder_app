const express = require('express');
const app = express();
const cors = require('cors');
const path = require("path");

app.use(cors());

//Routes
const taskRouter = require("./routes/task.router.js");
const db = require('./db/db.js');
// const { notFound } = require('./middlewares/404.js');


//Controllers
// const { getAllTasks, createTask, getTask, updateTask, deleteTask } = require('./controllers/task.controller.js');

//Middleware
app.use(express.static("../public"));
app.use(express.json());
// app.use(notFound);

// app.get("/", getAllTasks);

app.use("/tasks", taskRouter);

// app.get('*', (req, res) => {
//     res.sendFile(path.join(__dirname, '../frontend/index.html'));
// });

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Listening on PORT ${PORT}...`);
})
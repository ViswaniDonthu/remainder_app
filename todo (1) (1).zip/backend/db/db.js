const mongoose = require('mongoose');
const mongoURL = "mongodb://localhost:27017/";

mongoose.connect(mongoURL)
    .then(() => console.log(`DB Successfully Connected`))
    .catch((error) => console.log(error));

const db = mongoose.connection;

db.on("connected", () => {
    console.log(`DB Connected`);
})

db.on("disconnected", () => {
    console.log(`DB Disonnected`);
})

db.on("error", () => {
    console.log(`Error in Connection`);
})

module.exports = db;